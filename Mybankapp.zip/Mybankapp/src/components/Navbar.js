import React from 'react'
import { Link } from 'react-router-dom'
import "../CSS/navbar.css"
const Navbar = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-dark  text-light fixed-top" >
        <div className="container-fluid fs-5 ms-3">
          <Link className="navbar-brand navfont text-light" to="/"><h1>YES BANK</h1></Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon bg-light text-light"></span>
          </button>
          <div className="collapse navbar-collapse col-6 justify-content-end" id="navbarNavAltMarkup">
            <div class="topnav">
              <Link to="/"><i class="fa fa-fw fa-home"></i> Home</Link>
              {/* <Link to="#"><i class="fa fa-fw fa-search"></i> Search</Link> */}
               <Link to="/emplogin"><i class="fas fa-fw fa-user-tie"></i> Employe Login</Link>
              <Link to="/login"><i class="fa fa-fw fa-user"></i> Customer Login</Link>
            </div>
          </div>
        </div>
      </nav>
    </div>
  )
}

export default Navbar
