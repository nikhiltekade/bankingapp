import React from 'react'

const Rules = () => {
    return (
        <div>
           
                <h1 className="mb-5 text-center heading p-3">RULES AND TIMING</h1>
                <div className='rules  ms-5 me-5 row ' >
                <div className='bg-danger rounded text-light fw-bolder bg-gradient col-xl-12 col-sm-2 p-2 '><i className="fa fa-chevron-circle-right p-2 " aria-hidden="true"></i>Do Not Overdraw Your Checking Account.</div>
                    <div className='bg-warning rounded text-light fw-bolder bg-gradient col-xl-12 col-sm-2 p-2 mt-2' ><i className="fa fa-chevron-circle-right p-2" aria-hidden="true"></i>Keep the Required Minimum Savings Balance.</div>
                    <div className='bg-success  rounded text-light fw-bolder bg-gradient col-xl-12 col-sm-2 p-2 mt-2'><i className="fa fa-chevron-circle-right p-2" aria-hidden="true"></i> Set up Alerts for Suspicious Activity.</div>
                    <div className='bg-info rounded text-light fw-bolder bg-gradient col-xl-12 col-sm-2 p-2 mt-2'><i className="fa fa-chevron-circle-right p-2" aria-hidden="true"></i>Build a Relationship with Your Bank.</div>
                    <div className='bg-secondary rounded text-light fw-bolder bg-gradient col-xl-12 col-sm-2 p-2 mt-2'><i className="fa fa-chevron-circle-right p-2" aria-hidden="true"></i> Smoking Not Allow</div>
                    <div className=' bg-dark rounded text-light fw-bolder bg-gradient col-xl-12 col-sm-2 p-2 mt-2'><i className="fa fa-chevron-circle-right p-2" aria-hidden="true"></i> Lanuch Time 1.30pm to 2.00pm </div>

                </div>
                </div>

                )
}

                export default Rules