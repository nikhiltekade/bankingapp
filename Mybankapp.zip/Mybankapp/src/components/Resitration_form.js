import React from 'react'
import "../CSS/Resitration_form.css"
import Navbar from './Navbar';
const Resitration_form = () => {
  const [name, setName] = React.useState("")
  
  const [pan, setPan] = React.useState("")
  const [mobile, setMobile] = React.useState("")
  const [email, SetEmail] = React.useState("")
  const [address, setAddress] = React.useState("")
  const [gender, SetGender] = React.useState("")
  const [acctype, SetAcctype] = React.useState("")
  const [balance, setBalance] = React.useState("")



  const handlename = (event) => {
    setName(event.target.value);
  }
  
  const handlebalance = (event) => {
    setBalance(event.target.value);
  }
  const handlepancard = (event) => {
    setPan(event.target.value);
  }
  const handlemobile = (event) => {
    setMobile(event.target.value);
  }
  const handleemail = (event) => {
    SetEmail(event.target.value);
  }
  const handleaddress = (event) => {
    setAddress(event.target.value);
  }
  const handlegender = (event) => {
    SetGender(event.target.value);
  }
  const handleacctype = (event) => {
    SetAcctype(event.target.value);
  }
  function handleRegister(e) {
    alert("succsessfuly submitted")
    e.preventDefault();
    const setData = async () => {
      try {
        const result = await fetch("http://localhost:4501/post", {
          method: "post",
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify({
            Name: name,
            Account_Number: 0,
            Pancard: pan,
            Address: address,
            Balance: balance,
            Email: email,
            Account_Type:acctype,
            Mobile: mobile,
            Gender: gender,

          })
        })
        const response = await result.json();

        console.log(response);

        alert("Account opened successfully..");
      }
      catch (error) {
        console.log(error);
      }
    }
  
    setData();
  }
    return (
      <div>
        <Navbar />
        <div className='heading'><h2>Resitration Form</h2></div>
        <div className='form '>
          <form onSubmit={handleRegister} method='post'>

            <div className='row'>
              <div class="mt-4 col">
                <label for="Name" class="form-label">Name:</label>
                <input type="text" class="form-control" id="name" placeholder="Enter name" required onChange={handlename} />
              </div>
              <div class="mt-4 col">
                <label for="last_Name" class="form-label">Balance</label>
                <input type="text" class="form-control" id="Balance" placeholder="Enter amount" required onChange={handlebalance} />
              </div>
            </div>


            <div className='row'>
              <div class=" mt-4 col">
                <label for="Mobile_Number" class="form-label">Mobile Number</label>
                <input type="number" class="form-control" id="mobile_number" placeholder="Enter Mobile Number" required onChange={handlemobile} />
              </div>
              <div class=" mt-4 col">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="email" placeholder="Enter email" onChange={handleemail} />
              </div>
            </div>

            <div className='row'>
              <div class=" mt-2 col">
                <label for="pancard" class="form-label form-control-sm">PAN-Card Number</label>
                <input type="text" class="form-control" id="pancard" placeholder="Enter PAN number " required onChange={handlepancard} />
              </div>
              <div class="mt-2 p-2 col address ">
                <label for="Add" class="form-label">Address</label>
                <textarea type="add" class="form-control " id="add" placeholder="Enter Adress" required onChange={handleaddress} />
              </div>
            </div>

            <div className='row mt-3'>
              <div className='col '>
            <label for="acctype">Account Type</label>
                    <select className="form-control" id="acctype" onChange={handleacctype}>
                        <option>Select Account Type</option>
                        <option>Saving</option>
                        <option>Current</option>
                    </select>
            </div>
      

            <div className='col  mt-2'>
            <div className="form-group " onChange={handlegender}>
                    <label for="gender" className="d-block ">Gender</label>
                    <input type="radio" id="dob" name="gender" className="me-2" value="Male"/><span className="me-3">Male</span>
                    <input type="radio" id="dob" name="gender" className="me-2" value="Female"/><span className="me-3">Female</span>
                </div>

            </div>
            </div>
          
            <button type="submit" class="btn btn-success form-control green" >Submit</button>
          </form>
        </div>
      </div>

    )
  }


  export default Resitration_form;
