import React from 'react'
import { Link } from 'react-router-dom'
const Empnav = () => {
  return (
    <div>
        <nav className="navbar navbar-expand-lg bg-dark  text-light fixed-top" >
        <div className="container-fluid fs-5 ms-3">
          <a className="navbar-brand navfont text-light" href="#"><h1>VJS BANK</h1></a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon bg-light text-light"></span>
          </button>
          <div className="collapse navbar-collapse col-6 justify-content-end" id="navbarNavAltMarkup">
            <div class="topnav">
              <Link to="/"><i class="fa fa-fw fa-home"></i> Home</Link>
              {/* <Link to="#"><i class="fa fa-fw fa-search"></i> Search</Link>*/}
               <Link to="/Registration"><i class='fas fa-user-plus'></i> Add Customer</Link> 
              <Link to="/emplogin"><i class="fa-light fa fa-sign-out p-2" style={{fontSize:"24px"}}></i>Logout</Link>
            </div>
          </div>
        </div>
      </nav>
      
    </div>
  )
}

export default Empnav
