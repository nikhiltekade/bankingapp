import React, { useEffect } from 'react'
import Logoutnav from './Logoutnav'
import "../CSS/cbal.css"
import { Link } from 'react-router-dom'
const Checkbalance = () => {
  const [account,setAccount]=React.useState("");
  
  const handleaccount=(event)=>
  { 
     setAccount(event.target.value)
  }
  const handleclick=(event)=>{
    alert("Fetch")
    
    event.preventDefault();
   
    const getdata=async()=>{
              const output=await fetch("http://localhost:4501/checkbal/"+ account)
              const result=await output.json();
              if(result.length){
                console.log(result)
              }
              else{
                console.log("account number not valid")
              }
           
       
              
  }
  getdata();  
}
  

  return (
    <div>
      <Logoutnav />
      <div className='heading'><h2>CHECK BALANCE</h2></div>
      <form onSubmit={handleclick}>

        <div className='Cbal '>

          <div className='row'>
            <div class="col">
              <label for="Accno" class="form-label fw-bold">Account Number:</label>
              <input type="text" class="form-control" id="accno" placeholder="Enter Account Number" name="accno" required onChange={handleaccount}/>
            </div>
          </div>
        </div>
        <div className='text-center'>
            <button type="submit" class="btn btn-success fw-bold  mt-3  " >Click here</button>
            <button className='btn btn-danger fw-bold ms-2 mt-3'><Link className='text-decoration-none text-light' to="/customer">Cancel</Link></button>
          </div>
      </form>
        
    </div>
  )
}

export default Checkbalance
