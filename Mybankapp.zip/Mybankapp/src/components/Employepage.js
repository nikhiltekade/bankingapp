import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "../CSS/Employepage.css"
import Empnav from "./empnav";
const Employepage = () => {
    const [data, setData] = React.useState([])
    const [id,setID]=React.useState(0)
    useEffect(() => {
        getDeatail();
    }, []);
    const getDeatail = async () => {
        const output = await fetch("http://localhost:4501/")
        const result = await output.json();
        console.log(result)
        setData(result)
    }
   


    

    const handleDelete = (Account_Number) => {
        console.log("delete sr.id " + Account_Number)

        const deleteApi = async () => {
            const result = await fetch("http://localhost:4501/delete/" + Account_Number, {
                method: "delete"
            })
            const response = await result.json();
            console.log (response)
        }
        if (window.confirm("Are you sure !")) {
            deleteApi();
            getDeatail();
        }

        

    }

    return (
        <div>
            <Empnav />

            <div className="loginmain px-5">

                <table className="table table-striped">
                    <thead>
                        <tr className="bg-new text-center" >
                       
                            <th >Account Number</th>
                            <th>Name</th>
                            <th>Pancard Number</th>
                            <th>Mobile Number</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Account_type</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map(ele =>

                                <tr key={ele.Account_Number} className="text-center"><td>{ele.Account_Number}</td><td>{ele.Name}</td><td>{ele.Pancard}</td><td>{ele.Mobile}</td><td>{ele.Email}</td><td>{ele.Address}</td><td>{ele.Account_Type}</td><td onClick={() => handleDelete(ele.Account_Number)}><Link><i class="fa-solid fa-trash"></i></Link></td></tr>


                                // <tr key={ele.Uid} className="text-center" ><td>{ele.Name}</td><td>{ele.Email}</td><td>{ele.Contact}</td><td>{ele.UserSeat}</td><td><Link to={`/userDetail/${ele.Uid}`}><i class="fa-sharp fa-solid fa-eye"></i></Link></td><td><Link to={`/edit/${ele.Uid}`}><i class="fa-solid fa-pencil"></i></Link></td><td onClick={() => handleDelete(ele.Uid)}><Link><i class="fa-solid fa-trash"></i></Link></td></tr>

                                //  <tr key={ele.Uid} className="text-center"><td>{ele.Name}</td><td>{ele.Email}</td><td>{ele.Contact}</td><td>{ele.UserSeat}</td><td><Link to={`/userDetail/${ele.Uid}`}><i class="fa-sharp fa-solid fa-eye"></i></Link></td><td><input type="button" value="click me" name={ele.Uid}  onClick={handleBtn}/></td></tr>
                            )
                        }
                    </tbody>
                </table>
                {/* {flag &&
                    <div><UserDisplay userId={id} /></div>} */}
            </div>

        </div>
    );
};

export default Employepage;
