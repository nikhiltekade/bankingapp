import React from 'react'
import { Link } from 'react-router-dom'
import Logoutnav from './Logoutnav'
import  "../CSS/withdraw.css"
const Withdraw = () => {
  return (
    <div>
       <Logoutnav />
      <div className='heading'><h2>WITHDRAW</h2></div>
      <form>

        <div className='Withdraw '>

          <div className='row'>
            <div class="col">
              <label for="Accno" class="form-label fw-bold">Account Number:</label>
              <input type="number" class="form-control" id="accno" placeholder="Enter Account Number" name="accno" required />
            </div>
            <div class="col">
              <label for="Amt" class="form-label fw-bold">Amount</label>
              <input type="number" class="form-control" id="amt" placeholder="Enter Amount" name="amt" required />
            </div>
          </div>
          <div className='text-center'>
            <button class="btn btn-success fw-bold  mt-3  " > Withdraw</button>
            <button className='btn btn-danger fw-bold ms-2 mt-3'><Link className='text-decoration-none text-light' to="/customer">Cancel</Link></button>
          </div>
        </div>
      </form>
    </div>
  )
}

export default Withdraw
